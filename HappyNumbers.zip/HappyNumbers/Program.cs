﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace HappyNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("These are the first eigth happy Numbers");

            int startingNumber = 1;
            int happyNumbersCount = 0;
            int currentNumber = startingNumber;
            int calculatedNumber = currentNumber;
            List<int> listOfInts = new List<int>();

            int unlimitedLoopStopper = 0;

            while (happyNumbersCount < 8)
            {
                while (currentNumber != 1 && unlimitedLoopStopper < 10000)
                {
                    while (calculatedNumber > 0)
                    {
                        listOfInts.Add(calculatedNumber % 10);
                        calculatedNumber = calculatedNumber / 10;
                    }
                    listOfInts.Reverse();
                    int allIntsCalculated = 0;
                    foreach (int item in listOfInts)
                    {
                        allIntsCalculated = allIntsCalculated + item * item;
                    }
                    currentNumber = allIntsCalculated;
                    calculatedNumber = currentNumber;
                    listOfInts.Clear();
                    unlimitedLoopStopper++;
                }
                if (unlimitedLoopStopper < 10000)
                {
                    happyNumbersCount++;
                    Console.WriteLine(startingNumber.ToString());
                }
                unlimitedLoopStopper = 0;
                startingNumber++;
                currentNumber = startingNumber;
                calculatedNumber = currentNumber;
            }

            Console.ReadKey();
        }
    }
}
